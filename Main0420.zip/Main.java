import java.util.*;

class Main {
  public static void main(String[] args) {
    // Scanner sc = new Scanner(System.in);
    // System.out.printf("문자를 하나 입력하세요. ");
    // char ch = ' ';

    // String input = sc.nextLine();
    // ch = input.charAt(0);

    // if('0' <= ch && ch <= '9') {
    //   System.out.printf("입력하신 문자는 숫자입니다. %n");
    // } if(('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z')) {
    //   System.out.printf("입력하신 문자는 영문자입니다. %n");
    // }

    // 3-32 삼황 연산자
    // int x, y, z;
    // int absX, absY, absZ;
    // char signX, signY, signZ;

    // x = 10;
    // y = -5;
    // z = 0;

    // absX = x >= 0 ? x : -x; // x의 값이 음수이면, 양수로 만든다.
    // absY = y >= 0 ? y : -y;
    // absZ = z >= 0 ? z : -z;

    // signX = x > 0 ? '+' : (x == 0 ? ' ' : '-'); // 조건 연산자를 중첩
    // signY = y > 0 ? '+' : (y == 0 ? ' ' : '-');
    // signZ = z > 0 ? '+' : (z == 0 ? ' ' : '-');

    // System.out.printf("x = %c%d%n", signX, absX);
    // System.out.printf("y = %c%d%n", signY, absY);
    // System.out.printf("z = %c%d%n", signZ, absZ);


    // 4-1 Flow
    // int x = 0;
    // System.out.printf("x = %d 일때, 참인것은 %n", x);

    // if(x == 0) System.out.println("x == 0");
    // if(x != 0) System.out.println("x != 0");
    // if(!(x == 0)) System.out.println("!(x == 0)");
    // if(!(x != 0)) System.out.println("!(x != 0)");

    // x = 1;
    // System.out.printf("x = %d 일때, 참인것은 %n", x);

    // if(x == 0) System.out.println("x == 0");
    // if(x != 0) System.out.println("x != 0");
    // if(!(x == 0)) System.out.println("!(x == 0)");
    // if(!(x != 0)) System.out.println("!(x != 0)");


    // 4-2 Flow2
    // int input;
    // System.out.print("숫자를 하나 입력하세요. ");

    // Scanner sc = new Scanner(System.in);
    // String tmp = sc.nextLine();
    // input = Integer.parseInt(tmp);

    // if(input==0) {
    //   System.out.println("입력하신 숫자는 0입니다. ");
    // }

    // if (input != 0)
    //   System.out.println("입력하신 숫자는 0이 아닙니다. ");
    //   System.out.printf("입력하신 숫자는 %d 입니다.", input);

    // 4-4 Flow4
    // int score;
    // char grade = ' ', opt = '0';

    // System.out.print("점수를 입력하세요> ");
    // Scanner sc = new Scanner(System.in);
    // score = sc.nextInt();

    // if (score >= 90) {
    //   grade = 'A';
    //   if (score >= 98) {
    //     opt = '+';
    //   } else if(score < 94) {
    //     opt = '-';
    //   }
    // } else if (score >= 80) {
    //   grade = 'B';
    //   if (score >= 88) {
    //     opt = '+';
    //   } else if(score < 84){
    //     opt = '-';
    //   }
    // } else if (score >= 70) {
    //   grade = 'C';
    //   if (score >= 78) {
    //     opt = '+';
    //   } else if (score < 74){
    //     opt = '-';
    //   }
    // } else {
    //   grade = 'D';
    //   if (score >= 68) {
    //     opt = '+';
    //   } else if(score < 64) {
    //     opt = '-';
    //   }
    // }
    // System.out.printf("당신의 학점은 %c%c 입니다.", grade, opt);


    // 4-6
    // System.out.print("현재 월을 입력하세요.> ");
    // Scanner sc = new Scanner(System.in);
    // int month = sc.nextInt();

    // switch(month) {
    //   case 3:
    //   case 4:
    //   case 5:
    //     System.out.println("현재의 계절은 봄입니다. ");
    //     break;
    //   case 6:
    //   case 7:
    //   case 8:
    //     System.out.println("현재의 계절은 여름입니다. ");
    //     break;
    //   case 9:
    //   case 10:
    //   case 11:
    //     System.out.println("현재의 계절은 가을입니다. ");
    //     break;
    //   case 12:
    //   case 1:
    //   case 2:
    //     System.out.println("현재의 계절은 봄입니다. ");
    //     break;
    // }
    // 4-7 가위바위보
    // System.out.print("가위(1), 바위(2), 보(3) 중 하나를 입력하세요 ");
    // Scanner sc = new Scanner(System.in);
    // Random rand = new Random();
    // int user = sc.nextInt();
    // int com = rand.nextInt(3);
    // System.out.println("당신은 " + user + "입니다. ");
    // System.out.println("컴은 " + com + "입니다. ");

    // switch(user-com) {
    //   case 2: case -1:
    //     System.out.println("당신이 졌습니다. ");
    //     break;
    //   case 1: case -2:
    //     System.out.println("당신이 이겼습니다. ");
    //     break;
    //   case 0:
    //     System.out.println("비겼습니다.");
    //     break;
    // }

    // 4-8
    // System.out.print("당신의 주민번호를 입력하세요. ");
    // Scanner sc = new Scanner(System.in);
    // String regNo = sc.nextLine();

    // char gender = regNo.charAt(7);
    // switch(gender) {
    //   case '1': case '3':
    //     System.out.println("당신의 남자입니다. ");
    //     break;
    //   case '2': case '4':
    //     System.out.println("당신의 여자입니다. ");
    //     break;
    //   default:
    //     System.out.println("유효하지 않은 주민등록번호입니다. ");
    // }
    
    // 4-9
    // int score = 0;
    // char grade = ' ';
    // System.out.print("당신의 점수를 입력하세요. ");
    // Scanner sc = new Scanner(System.in);
    // String tmp = sc.nextLine();
    // score = Integer.parseInt(tmp);

    // switch(score/10) {
    //   case 10:
    //   case 9:
    //     grade = 'A';
    //     break;
    //   case 8:
    //     grade = 'B';
    //     break;
    //   case 7:
    //     grade = 'C';
    //     break;
    //   default: 
    //     grade = 'F';
    // }
    // System.out.println("당신의 학점은 " + grade + " 입니다.");

    // 4-10 switch문 중첩
    // System.out.print("당신의 주민번호를 입력하세요. ");

    // Scanner sc = new Scanner(System.in);
    // String regNo = sc.nextLine();
    // char gender = regNo.charAt(7);

    // switch(gender) {
    //   case '1': case '3':
    //     switch (gender) {
    //       case '1':
    //         System.out.println("당신은 2000년 이전에 출생한 남자입니다. ");
    //         break;
    //       case '3':
    //         System.out.println("당신은 2000년 이후에 출생한 남자입니다. ");
    //         break;
    //     }
    //   case '2': case '4':
    //     switch(gender) {
    //       case '2':
    //         System.out.println("당신은 2000년 이전에 출생한 여자입니다. ");
    //         break;
    //       case '4':
    //         System.out.println("당신은 2000년 이후에 출생한 남자입니다. ");
    //         break;
    //     }
    //     break;
    //   default:
    //     System.out.println("유효하지 않은 주민등록번호입니다. ");
    // }


    // 4-13
    // int sum = 0;

    // for (int i=1; i <= 10; i++) {
    //   sum += i;
    //   System.out.printf("1부터 %2d 까지의 합: %2d%n", i, sum);
    // }

    // for (int i = 1; i <= 5; i++){
    //   for (int j = 1; j <= i; j++) {
    //     System.out.print("*");
    //   }
    //   System.out.println();
    // }

    // 4-22
    // int[] arr = {10,20,30,40,50};
    // int sum = 0;

    // for(int i = 0; i < arr.length;i++) {
    //   System.out.printf("%d", arr[i]);
    // }System.out.println();

    // for(int temp : arr) {
    //   System.out.printf("%d", temp);
    //   sum += temp;
    // }
    // System.out.println();
    // System.out.println("sum = " + sum);


    // 4-24 while 문자는
    // int i = 11;
    // System.out.println("카운트 다운을 시작합니다.");
    // while(i-- != 0) {
    //   System.out.println(i);
    //   for(int j = 0; j <2_000_000_000; j++) {
    //     ;
    //   }
    // }

    // System.out.println("GAME OVER");


    // 4-26
    // int num = 0; 
    // int i  = 0;
    

    // while((num += ++i) <= 100) {
    //   System.out.printf("%d - %d%n", i , num);
    // }


    // 4-27
    // int num;
    // int sum = 0;
    // boolean flag = true;
    // Scanner sc = new Scanner(System.in);
    // System.out.println("합계를 구할 숫자를 입력하세요.(끝내려면 0을 입력)");
    // while (flag) {
    //   System.out.print(">>");

    //   String tmp = sc.nextLine();
    //   num = Integer.parseInt(tmp);

    //   if(num!=0) {
    //     sum += num;
    //   } else {
    //     flag = false;
    //   }
    // }
    // System.out.println("합계:" + sum);


    //4-28 숫자 찾기
    // int input = 0, answer = 0;
    // answer = (int)(Math.random() * 100) + 1;
    // Scanner sc = new Scanner(System.in);

    // do {
    //   System.out.print("1과 100사이의 정수를 입력하세요. ");
    //   input = sc.nextInt();

    //   if(input > answer) {
    //     System.out.println("더 작은 수로 다시 시도해보세요. ");
    //   } else if(input < answer) {
    //     System.out.println("더 큰 수로 다시 시도해보세요. ");
    //   } 
    // }while(input != answer);
    // System.out.println("정답입니다.");


    //4-29 3의 배수

    // for(int i = 1; i <=100; i++) {
    //   System.out.printf("i=%d", i);
    //   int tmp = i;

    //   do {
    //     if(tmp%10%3 == 0 && tmp % 10 != 0) //tmp % 10 이 3의 배수인지 확인
    //       System.out.print("짝");
    //   }while ((tmp/=10) != 0); // tmp /= 10 은 tmp = tmp /10과 동일
    //   System.out.println();
    // }

    //4-32
    int menu = 0;
    int num = 0;
    Scanner sc = new Scanner(System.in);

    while (true) {
      System.out.println("(1) squere");
      System.out.println("(2) squere root");
      System.out.println("(3) log");
      System.out.println("원하는 메뉴(1~3) 를 선택하세요. (종료 0) ");

      String tmp = sc.nextLine();
      menu = Integer.parseInt(tmp);

      if(menu == 0) {
        System.out.println("프로그램을 종료합니다. ");
         break;
      } else if (!(1 <= menu && menu <= 3)) {
        System.out.println("메뉴를 잘못 선택하셨습니다.(종료는 0)");
        continue;
      }
      System.out.println("선택하신 메뉴는 " + menu + "번 입니다.");
    }


  }
}
